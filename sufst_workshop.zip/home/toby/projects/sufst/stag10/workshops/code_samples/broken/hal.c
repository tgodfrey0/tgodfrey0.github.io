#include "hal.h"

#include <time.h>
#include <stdlib.h>

static uint8_t max_id = 0;

void init_sensor(struct sensor *s){
  s->id = (max_id++);
  s->initialised = true;
}

void read_sensor(struct sensor *s){
  s->value = (uint16_t) rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
}