#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <sys/cdefs.h>

struct sensor {
  uint8_t id;
  uint16_t value;
  bool initialised;
};

void init_sensor(struct sensor *s);
void read_sensor(struct sensor *s);
