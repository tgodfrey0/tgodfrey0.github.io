#ifndef FUN_H
#define FUN_H

#include <stdint.h>

uint16_t my_fun(uint16_t a, uint16_t b, uint16_t c);

#endif /* FUN_H */
