#include "fun.h"
#include "hal.h"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

// You can change the function signature
void init(){
  
}

// You can change the function signature
void run(){
  while(true){
    
  }
}

int main(int argc, char **argv){

  srand(time(NULL));

  init();

  run();

  return 0;
  
}
