#include "fun.h"
#include <stdint.h>
#include <stdio.h>

uint16_t my_fun(uint16_t a, uint16_t b, uint16_t c){
  
  return 0;
}
