#include "fun.h"
#include <stdint.h>
#include <stdio.h>

uint16_t my_fun(uint16_t a, uint16_t b, uint16_t c){
  printf("S1: %d\n", a);
  printf("S2: %d\n", b);
  printf("S3: %d\n\n", c);
  return 0;
}
