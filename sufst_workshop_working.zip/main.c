#include "fun.h"
#include "hal.h"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

void init(struct sensor s1, struct sensor s2, struct sensor s3){
  init_sensor(&s1);
  init_sensor(&s2);
  init_sensor(&s3);
}

void run(struct sensor s1, struct sensor s2, struct sensor s3){
  while(true){
    read_sensor(&s1);
    read_sensor(&s2);
    read_sensor(&s3);

    my_fun(s1.value, s2.value, s3.value);
  }
}

int main(int argc, char **argv){

  srand(time(NULL));

  struct sensor s1;
  struct sensor s2;
  struct sensor s3;

  init(s1, s2, s3);

  run(s1, s2, s3);

  return 0;
  
}
